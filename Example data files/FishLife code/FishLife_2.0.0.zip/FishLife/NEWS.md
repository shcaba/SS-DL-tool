FishLife 1.0.2 (2017-08-01)
=========================

### NEW FEATURES

  * Made new shiny package

### BUG FIXES

  * Fixed bugs related to renaming the package `FishLife`


FishLife 1.0.0 (2017-07-30)
=========================

### NEW FEATURES

  * first public release
